export default {
  spacing: (factor: number) => `${0.25 * factor}rem`
}
